This is a practice login GUI that I made.
Username is username and password is password (I know, very secure).
Anyways, have fun...logging in I guess?